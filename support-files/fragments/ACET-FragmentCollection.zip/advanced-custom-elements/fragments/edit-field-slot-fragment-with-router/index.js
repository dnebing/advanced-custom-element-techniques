import 'advanced-custom-element-techniques'

Liferay.on('allPortletsReady', function(){
	fragmentElement.querySelector('.fragment_acet_5').classList.remove('hide')
})